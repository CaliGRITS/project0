# Maximum contiguous subarray

**Problem:** You are to write a Ruby method that takes in one array as an argument and returns the maximum contiguous subarray, or summed set of numbers, of that array. The returned value should be the sum of this maximum contiguous subarray.

For example: 
Input: [-2,1,-3,5,-1,1,2,-5,4],

the contiguous subarray [5,-1,1,2] has the largest sum = 7. The value 7 should be returned.
