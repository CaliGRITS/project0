def max_contig_subarray(arr)
end

#some tests
puts max_contig_subarray([-2,1,-3,5,-1,1,2,-5,4]) #7
