# Create a method for each of the tasks below.
# The methods should return the expected value

# Add two numbers


# Subtract two numbers

# Add an array of numbers

# Multiply an array of numbers

# A method that takes two numbers and creates an exponent where num1 is raised to the power of num2
