def radix_sort(array)

end

print radix_sort([300,843,1111,23,912])
print radix_sort([239,40,150,282,60,2,2,120])
